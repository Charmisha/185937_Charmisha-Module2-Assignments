import { Injectable } from '@angular/core';                                                                                                                                                                                                                                                                                                                                                                 
import { Movies } from './movies';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class MovieService {
  moviesbyGenre:Array<Movies>;
  url:string="/assets/movies.json";
  movieList:Array<Movies>=[];
  constructor(private http:HttpClient) 
  { 
    this.getMovies().subscribe(data=>this.movieList=data);
  }
  getMovies():any
  {
    return this.http.get<Movies>(this.url);

  }
  addMovie(movie:Movies)
  {
    this.movieList.push(movie);
  }
  searchMovie(genre:String):Movies[]
  { 
    this.moviesbyGenre=[];
    for (let i of this.movieList) {
      if(i.genre === genre)
       this.moviesbyGenre.push(i);
    }
     return this.moviesbyGenre;
  }
}
